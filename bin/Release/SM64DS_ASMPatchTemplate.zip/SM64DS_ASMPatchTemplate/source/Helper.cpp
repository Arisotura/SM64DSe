#include "SM64DS.h"

MarioActor * PLAYER;

// Because the address at which the Player object is stored is not fixed when changes are made to the ROM or within 
// every level, we need to store the address whenever the game uses it so that we can retrieve it and modify the values 
// at that address later.

// The following code being hooked gets called when the game is first loaded and when the Player object's address changes.
void hook_020e6994_ov_02()
{
	asm
	(
		"ldr r0, =PLAYER	\n\t"		// r0 points to PLAYER address
		"str r5, [r0]		\n\t"			// store the value in r5 at the address stored in r0
		"original:			\n\t"
		"mov r0, r5			\n\t"
	);
}