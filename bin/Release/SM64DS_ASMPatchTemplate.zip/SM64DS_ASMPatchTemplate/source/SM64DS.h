#include <nds.h>

#define KEYS 		*((volatile unsigned int*)0x4000130)
#define CHARACTER 	*((volatile unsigned char*)0x0209CAE1)
#define LEVEL_ID 	*((volatile unsigned char*)0x0209F2F8)

#define  VERTICAL_SPEED_ZERO 	0xFFFF8000

struct MarioActor
{
	void* vtable;
	u32 unk004;
	u32 unk008;
	u32 unk00C;
	u32 unk010;
	u32 unk014;
	u32 unk018;
	u32 unk01C;
	u32 unk020;
	u32 unk024;
	u32 unk028;
	u32 unk02C;
	u32 unk030;
	u32 unk034;
	u32 unk038;
	u32 unk03C;
	u32 unk040;
	u32 unk044;
	u32 unk048;
	u32 unk04C;
	u32 unk050;
	u32 unk054;
	u32 unk058;
	u32 xPos; //05C
	u32 yPos;
	u32 zPos;
	u32 unk068;
	u32 unk06C;
	u32 unk070;
	u32 unk074;
	u32 unk078;
	u32 unk07C;
	u32 unk080;
	u32 unk084;
	u32 unk088;
	u32 unk08C;
	u32 unk090;
	u32 unk094;
	u32 forwardSpeed; // 098
	u32 unk09C;
	u32 unk0A0;
	u32 unk0A4;
	u32 verticalSpeed;	// 0A8
	// TODO: This struct's huge, add rest
};

extern MarioActor* PLAYER;

extern "C" 
{
    void Player_PerformAction(MarioActor *, char action, unsigned int loop_related, unsigned short playspeed_20_12);
}

void hook_020E5098();

enum Characters
{
	CHAR_Mario = 0,
	CHAR_Luigi = 1,
	CHAR_Wario = 2,
	CHAR_Yoshi = 3
};

enum PlayerActions
{
	ACT_SittingNoddingOff = 0x0C,
	ACT_HitAgainstWall = 0x12,
	ACT_LongJump = 0x1A,
	ACT_CrouchAfterLongJump = 0x1B,
	ACT_DismountFromHandstand = 0x1C,
	ACT_MaintainHandstand = 0x1D,
	ACT_StartHandstand = 0x1E,
	ACT_PullSelfUpFromHangingOffEdgeBothLegsTogether = 0x20,
	ACT_HangOffEdge = 0x21,
	ACT_StartToHangOffEdge = 0x22,
	ACT_PullSelfUpFromHangingOffEdgeRightLegFirst = 0x23,
	ACT_ClimbPole = 0x24,
	ACT_SlideDownPole = 0x25,
	ACT_HoldingOnToPole = 0x26,
	ACT_GrabPole = 0x27,
	ACT_WallJump = 0x28,
	ACT_SlideDownWall = 0x29,
	ACT_Backflip = 0x2A,
	ACT_LandAfterBackflip = 0x2B,
	ACT_Crouch = 0x2C,
	ACT_StartToCrouch = 0x2D,
	ACT_GetUpFromCrouch = 0x2E,
	ACT_Punch = 0x38,
	ACT_DoublePunch = 0x39,
	ACT_Kick = 0x3A,
	ACT_Run = 0x3F,
	ACT_SlideBackOnStomach = 0x43,
	ACT_QuicklyTurn = 0x45,
	ACT_SkidToHalt = 0x46,
	ACT_Wait = 0x47,
	ACT_Walk = 0x48,
	ACT_Fly = 0x49,
	ACT_TumbbleThenStartToFly = 0x4A,
	ACT_Tumble = 0x4B,
	ACT_LandAfterTripleJump = 0x4C,
	ACT_SideJump = 0x4D,
	ACT_ReachedPeakOfFirstOrSecondJump = 0x4F,
	ACT_StartToFallAfterJump = 0x50,
	ACT_LandOnGroundAfterJumpReachingPeak = 0x51,
	ACT_LandOnGroundAfterJump = 0x52,
	ACT_JumpStart = 0x53,
	ACT_Fall = 0x54,
	ACT_HeavyFall = 0x55,
	ACT_Tumble2 = 0x56,
	ACT_HangByLeftArm = 0x57,
	ACT_HangByRightArm = 0x58,
	ACT_MoveWhileHanging = 0x59,
	ACT_Sneak = 0x61,
	ACT_EndCrawl = 0x62,
	ACT_Crawl = 0x63,
	ACT_StartToCrawl = 0x64,
	ACT_PushAgainstSolidObject = 0x65,
	ACT_SlideBeforeSlideFlip = 0x67,
	ACT_SlideFlip = 0x68,
	ACT_SmallKnockBackFromHit = 0x69,
	ACT_MediumKnockBackFromHit = 0x6A,
	ACT_SpinAndPunchAirCelebrate = 0x6B,
	ACT_HitBackOfHead = 0x6D,
	ACT_PickedUpAndTrapped = 0x71,
	ACT_ShotFromCannon = 0x73,
	ACT_StuckInGroundStartPullingOut = 0x74,
	ACT_StuckInGroundLookAround = 0x75,
	ACT_StuckInGroundPullOut = 0x76,
	ACT_BumStuckInGroundPullOut = 0x77,
	ACT_BumStuckInGroundStartPullingOut = 0x78,
	ACT_BumStuckInGroundLookAround = 0x79,
	ACT_HeadStuckInGroundPullOut = 0x7A,
	ACT_HeadStuckInGroundIdle = 0x7B,
	ACT_HeadStuckInGroundEnter = 0x7C,
	ACT_DrowningInSand = 0x7D,
	ACT_PushingThroughDeepSand = 0x7E,
	ACT_KnockedBackOnBum = 0x7F,
	ACT_HoldOnToObjectInGround = 0x80,
	ACT_StartGrabbingObjectInGround = 0x81,
	ACT_StartToDrown = 0x82,
	ACT_DieInWater = 0x83,
	ACT_Drown = 0x84,
	ACT_CelebrateAfterExitingLevelWithStar = 0x85,
	ACT_StartToGrabObject = 0x86,
	ACT_HoldObject = 0x87,
	ACT_CarryObject = 0x88,
	ACT_HoldObject2 = 0x89,
	ACT_SetDownObject = 0x8A,
	ACT_StartToGrabCaughtRabbitAfterDive = 0x8B,
	ACT_RunAwayScared = 0x8C,
	ACT_OpenDoor = 0x8D,
	ACT_PickUpHugeObject = 0x8E,
	ACT_CarryHugeObject = 0x8F,
	ACT_HoldHugeObject = 0x90,
	ACT_ThrowHugeObject = 0x91,
	ACT_LaunchObjectIntoAir = 0x92,
	ACT_UnlockDoubleDoorWithKey = 0x93,
	ACT_FlipAndPutAwayKeyAfterReceiving = 0x94,
	ACT_HuddleInCold = 0x95,
	ACT_ShiverWhileHuddledInCold = 0x96,
	ACT_SwitchCaps = 0x98,
	ACT_SpinAndPutOnCap = 0x99,
	ACT_GrowFromSuperMushroom = 0x9A,
	ACT_ShrinkAfterSuperMushroom = 0x9B,
	ACT_LookDownAtHands = 0xA0,
	ACT_CheckForDamageAndShrug = 0xA5,
	ACT_KickingInWater = 0xA6,
	ACT_EnterWater = 0xA7,
	ACT_FloatInWater = 0xA8,
	ACT_StartBreastStroke = 0xA9,
	ACT_StartToEndSwimMotion = 0xAA,
	ACT_EndSwimMotion = 0xAB,
	ACT_GetStarUnderWater = 0xAC,
	ACT_KnockedBackUnderWater = 0xAD,
	ACT_TryToPunchUnderWater = 0xAE,
	ACT_GrabObjectUnderWater = 0xAF,
	ACT_SwimWhileHoldingObject = 0xB0,
	ACT_LoseObjectUnderWater = 0xB1,
	ACT_PointForwardStartIntro = 0xB2,
	ACT_StandStillStartIntro = 0xB3,
	ACT_SitAttentivelyStartIntro = 0xB4,
	ACT_StandStillSwaySlightly = 0xB5,
	ACT_PointToRightStartIntro = 0xB6,
	ACT_StandStillUnknown1 = 0xB7,
	ACT_StartToTurnToLookLeft = 0xB8,
	ACT_TurnedToLookLeft = 0xB9,
	ACT_TurnQuicklyToLookLeft = 0xBA,
	ACT_RevealStarAsWhenOpeningDoor = 0xBB,
	ACT_ArmsOutstretchedAfterRevealingStar = 0xBC,
	ACT_RemoveCapEndScene = 0xBD,
	ACT_WaitInFrontOfPeachEndScene = 0xBE,
	ACT_WaveEndScene = 0xBF,
	ACT_CollectFinalStarCelebrateAndTakeOff = 0xC0,
	ACT_FlyingFinalDefeat = 0xC1					// Final Valid Action
};